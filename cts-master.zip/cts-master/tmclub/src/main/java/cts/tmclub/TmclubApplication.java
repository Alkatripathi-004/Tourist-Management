package cts.tmclub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TmclubApplication {

	public static void main(String[] args) {
		SpringApplication.run(TmclubApplication.class, args);
	}

}

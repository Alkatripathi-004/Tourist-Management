package cts.tm.service;


import cts.tm.pojo.LoginPojo;

public interface LoginService {
	LoginPojo save(LoginPojo loginPojo);
}
